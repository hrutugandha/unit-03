
function friends(n,c,o){
    this.name = n;
    this.city = c;
    this.job = o;
}

function mySkills(s){
    this.skill = s;
}

var Friend = new friends("Amar","Goa","Singer");
var Friend1 = new friends("Akabar","Mumbai","Chef");
var Friend2 = new friends("Anthony","Kashmir","Magician");

mySkills.call(Friend,"Cooking");
mySkills.call(Friend1,"Magic");
mySkills.call(Friend2,"Singing")

console.log(Friend);
console.log(Friend1);
console.log(Friend2);


// now they can borrow each others skills.